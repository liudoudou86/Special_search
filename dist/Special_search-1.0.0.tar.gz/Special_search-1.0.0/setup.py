# -*- coding:utf-8 -*-
# Author:lz

from distutils.core import setup

setup(
    name='Special_search',
    version='1.0.0',
    py_modules =['Special_search'],
    author='lz',
    author_email='543972930@qq.com',
    url='https://github.com/liudoudou86',
    
    description='搜索模块'
)